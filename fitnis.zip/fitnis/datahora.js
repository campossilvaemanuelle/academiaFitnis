function exibirDataAtual(){
    const agora= new Date();
    const dia= String(agora.getDate());
    const mes= String(agora.getMonth());
    const ano=agora.getFullYear();
    const dataformatada= `${dia}/${mes}/${ano}`;
    document.getElementById('data-blog').innerText=dataformatada;
}
exibirDataAtual();

function dataHora(){
    const agora = new Date();
    const hora = agora.toLocaleTimeString('pt-BR');
    const relogios = document.querySelectorAll('.relogio-post');
    relogios.forEach(relogio =>{
    relogio.innerHTML = hora;
    });
}
setInterval(dataHora,1000);
dataHora();